package com.app.dto;

public interface IListCategoryDto {
	public Long getId();

	public String getCategoryName();

}
