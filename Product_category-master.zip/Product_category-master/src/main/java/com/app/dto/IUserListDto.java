package com.app.dto;

public interface IUserListDto {

	public Long getId();

	public String getName();

	public String getEmail();

}
