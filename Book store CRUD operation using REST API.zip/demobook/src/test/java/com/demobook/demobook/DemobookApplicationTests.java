package com.demobook.demobook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemobookApplicationTests {

	@Test
	void contextLoads() {
	}

}
