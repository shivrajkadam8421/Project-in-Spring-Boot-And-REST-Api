package com.demobook.demobook.controllers;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.demobook.demobook.entities.book;
import com.demobook.demobook.services.bookservice;

@RestController
public class bookcontroller {

    @Autowired
    private bookservice bookservices;

    // get all books handler
    @GetMapping("/books")
     public List<book> getbooks()
    {
        
        return this.bookservices.getallbooks();
    }
    // get single books handler

    @GetMapping("/books/{id}")
    public book getbook(@PathVariable("id") int id)
    {
        return bookservices.getbookbyid(id);
    }

    // new book handler
    @PostMapping("/books")
    public book addbook(@RequestBody book b)
    {
        book br=this.bookservices.addbook(b);
        return br;
    }
    
    // delete book handler
    @DeleteMapping("/books/{bookId}")

    public void deletebook(@PathVariable("bookId") int bookId)
    {
        this.bookservices.deletebook(bookId);
    }
    
    // update book handler 
    @PutMapping("/books/{bookId}")
    public book updatebook(@RequestBody book b1,@PathVariable("bookId")int bookId)
    {
        this.bookservices.updatebook(b1,bookId);
        return b1;
    }

}
