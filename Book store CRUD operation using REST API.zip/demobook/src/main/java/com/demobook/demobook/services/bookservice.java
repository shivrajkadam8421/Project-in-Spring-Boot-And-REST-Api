package com.demobook.demobook.services;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.demobook.demobook.entities.book;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;

@Component
public class bookservice {

    private static List<book> list=new ArrayList<>();

    static {
        list.add(new book(12,"complete reference","XYZ"));
        list.add(new book(13,"think java","ABC"));
        list.add(new book(14,"core java","LMN"));
        
    }

    // get all books 

    public List<book> getallbooks()
    {
        return list;
    }

        //get single book by id 

public book getbookbyid(int id)
{
    book b2=null;
    b2=list.stream().filter(e->e.getId()==id).findFirst().get();

    return b2;
}

//adding the book 
public book addbook(book b)
{
    list.add(b);
    return b;
}
// delete book
public void deletebook(int bid)
{
    list=list.stream().filter(book->book.getId()!=bid).
    collect(Collectors.toList());
}

//update the book
public void updatebook(book boo,int bookId)
{
    list= list.stream().map(b->{
        if(b.getId()==bookId)
        {
            b.setTitle(b.getTitle());
            b.setAuthor(b.getAuthor());
        }
        return b;
    }).collect(Collectors.toList());

}
}
