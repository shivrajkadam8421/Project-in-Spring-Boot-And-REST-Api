package com.demobook.demobook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemobookApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemobookApplication.class, args);
	}

}
