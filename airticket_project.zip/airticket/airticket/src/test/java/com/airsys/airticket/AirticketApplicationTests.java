package com.airsys.airticket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirticketApplicationTests {

	@Test
	void contextLoads() {
	}

}
