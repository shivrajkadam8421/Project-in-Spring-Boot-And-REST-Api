package com.airsys.airticket.entity;

import jakarta.persistence.OneToOne;

public class flite {
    private Long id;
    private String name;
     private  Long seat;

     @OneToOne
    private  AirFleet airFleet;

     @OneToOne
    private  Source source;

     @OneToOne
    private  Destination destination;
}
