package com.airsys.airticket.service;

public class SourceDestinationError extends Throwable {
    public SourceDestinationError(String s) {
    }
}
