package com.airsys.airticket.controller;

import com.airsys.airticket.entity.Destination;
import com.airsys.airticket.service.DestinationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class DestinationController {
@Autowired private DestinationService destinationService;
    @PostMapping("/saveDestination")
    public Destination saveDestination(@RequestBody Destination destination){
        Destination destination1=destinationService.saveDestination(destination);
        return destination1;
    }


    @GetMapping("/showDestination")
    public List<Destination> showDestination(){

        return destinationService.showDestination();
    }

}
