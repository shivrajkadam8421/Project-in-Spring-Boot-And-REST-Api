package com.airsys.airticket.exception;

public class ourceDestinationError extends Exception{
    public SourceDestinationError() {
    }

    public SourceDestinationError(String message) {
        super(message);
    }
}
