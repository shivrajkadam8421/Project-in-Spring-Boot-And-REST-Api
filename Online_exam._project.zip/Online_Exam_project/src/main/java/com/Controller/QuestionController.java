package com.Controller;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.Entity.Answer;
import com.Entity.Questions;


@Controller
public class QuestionController {
	
	@RequestMapping("saveResponse")
	public void saveResponse(Answer answer,HttpServletRequest request ) {
		
		System.out.println(answer);
		
		HttpSession httpsession=request.getSession();
		

		List<Questions> listofquestions=(List<Questions>) httpsession.getAttribute("allquestions");
		// here given all questions details but we want perticular question
		
		
		Questions question=listofquestions.get((int) httpsession.getAttribute("qno"));
		// so here we get particular question 
		
		
		String originalAnswer=question.getAnswer();//and get method give answer 
		
		
		System.out.println(originalAnswer);
		
		answer.setOriginalAnswer(originalAnswer);
		
		HashMap<Integer,Answer> hashmap=(HashMap<Integer, Answer>) httpsession.getAttribute("submittedDetails");
		 // using type casting because return type is object of getAttribute method
		
		hashmap.put(answer.qno, answer);
		
		System.out.println(httpsession.getAttribute("submittedDetails")); // here give all submitted details like qno,question,option,answer
		
		
		
		
	}
	
	@RequestMapping("endExam")
	
	public ModelAndView endExam(HttpServletRequest request) {
		
		HttpSession httpsession=request.getSession();
		
		HashMap<Integer,Answer> hashmap=(HashMap<Integer, Answer>) httpsession.getAttribute("submittedDetails");
		 
		ModelAndView mvc=new ModelAndView();
		mvc.setViewName("score");
		if(hashmap!=null) {
		Collection<Answer> collection=hashmap.values();
		
		for (Answer answer : collection) {
			if(answer.originalAnswer.equals(answer.submittedAnswer)) {
				
				httpsession.setAttribute("score", (int)httpsession.getAttribute("score")+1);
			
		}
		}
		
		
		

//		mvc.addObject("score",httpsession.getAttribute("score"));
		//mvc.addObject("allanswers",collection);
         
		httpsession.setAttribute("allanswers",collection);
		
		
		httpsession.removeAttribute("submittedDetails");
		
		}
		return mvc;
	
	}
	

	@RequestMapping("next")
	public ModelAndView next(HttpServletRequest request)
	{
		ModelAndView modelAndView=new ModelAndView();
		
		
		
		HttpSession httpsession=request.getSession();
	   List<Questions> listofquestions=(List<Questions>)httpsession.getAttribute("allquestions");
		
		if((int)httpsession.getAttribute("qno")<=listofquestions.size()-2) //3-2=1 i.e 1 index element
		{
			
		
		
		httpsession.setAttribute("qno",(int)httpsession.getAttribute("qno")+1);
		
		//List<Questions> listofquestions=(List<Questions>)httpsession.getAttribute("allquestions");
		Questions question=listofquestions.get((int)httpsession.getAttribute("qno"));
		
		int qno=question.getQno();//retrieve qno
		
		HashMap<Integer,Answer> hashmap=(HashMap<Integer, Answer>) httpsession.getAttribute("submittedDetails");
		
		 Answer answer=hashmap.get(qno);
		 
		 String previousAnswer="";
		 if(answer!=null) {
			 previousAnswer= answer.submittedAnswer; 
		 }

		modelAndView.setViewName("questions");
		modelAndView.addObject("question",question);
		

		modelAndView.addObject("previousAnswer" ,previousAnswer);
	}
		
		else {
			modelAndView.setViewName("questions");
			
			modelAndView.addObject("question",listofquestions.get(listofquestions.size()-1));//
			
			modelAndView.addObject("message","questions are over!");
		}
		return modelAndView;
		
		
			
	}
	
	

	@RequestMapping("previous")
	public ModelAndView nprevious(HttpServletRequest request)
	{
		ModelAndView modelAndView=new ModelAndView();
		
		
		
		HttpSession httpsession=request.getSession();
	   List<Questions> listofquestions=(List<Questions>)httpsession.getAttribute("allquestions");
		
		if((int)httpsession.getAttribute("qno")>0) {
			
		
		
		httpsession.setAttribute("qno",(int)httpsession.getAttribute("qno")-1);
		
		//List<Questions> listofquestions=(List<Questions>)httpsession.getAttribute("allquestions");
		Questions question=listofquestions.get((int)httpsession.getAttribute("qno"));
		
		int qno=question.getQno(); //retrieve qno 
		

		HashMap<Integer,Answer> hashmap=(HashMap<Integer, Answer>) httpsession.getAttribute("submittedDetails");
		 //above is hash map we get all details 
		
	
		Answer answer=hashmap.get(qno);
		
		String previousAnswer=" ";
		if(answer!=null) {
			previousAnswer=answer.submittedAnswer;
			
		}

		modelAndView.setViewName("questions");
		modelAndView.addObject("question",question);
		
		modelAndView.addObject("previousAnswer" ,previousAnswer);
	}
		
		else {
			modelAndView.setViewName("questions");
			
			modelAndView.addObject("question",listofquestions.get(listofquestions.size()-3));
			
			modelAndView.addObject("message","questions are over!");
		}
		return modelAndView;
		
		
			
	}
	
}
