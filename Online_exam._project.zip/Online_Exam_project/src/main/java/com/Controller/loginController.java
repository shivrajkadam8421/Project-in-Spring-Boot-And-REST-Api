package com.Controller;
    import java.io.File;
    import java.util.HashMap;
	import java.util.List;

	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpSession;

	import org.hibernate.Query;
	import org.hibernate.Session;
	import org.hibernate.SessionFactory;
    import org.hibernate.Transaction;
    import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Controller;
	import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.Entity.Answer;
import com.Entity.Questions;
	
	import com.Entity.User;



	@Controller
	public class loginController 
	{
		@Autowired
		
		SessionFactory factory;

		// localhost:8080/login
		@RequestMapping("login")
		public String login()
		{
			return "login";  // here login is jsp page name
		}
		
		@RequestMapping("admin")
		public String questionManagement()
		{
			return "questionManagement";  // here login is jsp page name
		}
		
		
		@RequestMapping("validate")
		public ModelAndView validate(String username,String password,HttpServletRequest request)
		{
			ModelAndView modelandview=new ModelAndView();
			
			Session session=factory.openSession();

			User userfromdb=session.get(User.class,username);
				
			if(userfromdb==null)
			{
				modelandview.setViewName("login"); // view page name means JSP page name
				modelandview.addObject("message","wrong username"); // here message attribute represents data which will be displayed on view page . here message is called model attribute
				
			}
			
			else if(userfromdb.password.equals(password))
			{
				modelandview.setViewName("welcome"); // view page name means JSP page name
				
				HttpSession httpsession=request.getSession();
				
				httpsession.setAttribute("username",username);
				
			}
			
			else
			{
				modelandview.setViewName("login"); // view page name means JSP page name
				modelandview.addObject("message","wrong password"); // here message attribute represents data which will be displayed on view page . here message is called model attribute
			}
			
			return modelandview;
		
		
		}
		

		@RequestMapping("startExam")
		public ModelAndView startExam(String selectedSubject,HttpServletRequest request)
		{
			System.out.println(selectedSubject);
		
			ModelAndView modelAndView=new ModelAndView();
			
			if(selectedSubject==null)
			{
				modelAndView.setViewName("login");
			}
			else
			{
			Session session=factory.openSession();
			
			/* Criteria is for only fetching records ( select query)
			 * HQL is for all operations (insert , update,delete,select )
			 *  */
			// using add() we add condition , based on which records are fetched from database
			// e.g. we want only those records which are having value maths for subject column ( assume selectedsubject is maths)
			// select * from questions where subject='maths'
			//List listOfQuestions=session.createCriteria(Questions.class).add(Restrictions.eq("subject",selectedSubject)).list();
			
			HttpSession httpsession=request.getSession();
			httpsession.setAttribute("qno",0);
			httpsession.setAttribute("timeremaining",121);
			
		//	Query query=session.createQuery("from Questions where subject=:subject order by rand()");
			Query query=session.createQuery("from Questions where subject=:subject");
			query.setParameter("subject",selectedSubject);
			List<Questions> listOfQuestions=query.list();
			System.out.println(" questions from databases "+listOfQuestions );
			
			modelAndView.setViewName("questions");
			modelAndView.addObject("listOfQuestions",listOfQuestions);
			modelAndView.addObject("question",listOfQuestions.get(0));
			httpsession.setAttribute("allquestions",listOfQuestions);
		
			HashMap<Integer,Answer> hashmap=new HashMap<Integer, Answer>();//hash map is user specify
			//if we adding adding ans=10 but we want to change i.e ans=11 then using hash map it is possible
			// hashmap store new key with value
			httpsession.setAttribute("submittedDetails",hashmap);
			
			httpsession.setAttribute("score",0);
			httpsession.setAttribute("subject",selectedSubject);
			}
			return modelAndView;
		
		}
		

		@RequestMapping("register")
		public String register() {
			return "register";
			
			
		 }
		
		@RequestMapping("saveUserData")
		ModelAndView saveUserData(User datafromuser,HttpServletRequest request) {
			
		
				MultipartFile filedata=datafromuser.getImages();
					
				// MultipartFile object contains image data
				
				String filename=filedata.getOriginalFilename();
				
				System.out.println(filename);// xyz.jpg
				

				HttpSession httpsession=request.getSession();
				httpsession.setAttribute("imagename",filename);
				
						
				File file=new File(request.getServletContext().getRealPath("/images"),filename);
						
				try 
				{
					
					filedata.transferTo(file);
					
					System.out.println("File uploaded successfully");
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
			ModelAndView modelandview=new ModelAndView();
			Session session=factory.openSession();
			Transaction ts=session.beginTransaction();
			
			datafromuser.setImagepath(filename);
			
			session.save(datafromuser);
			
			modelandview.setViewName("login");
			modelandview.addObject("message", "register successfully");
			ts.commit();
			
			return modelandview;
			
			
			
		}
//		@RequestMapping("next")
//		public ModelAndView next(HttpServletRequest request)
//		{
//			ModelAndView modelAndView=new ModelAndView();
//			
//			
//			
//			HttpSession httpsession=request.getSession();
//		   List<Questions> listofquestions=(List<Questions>)httpsession.getAttribute("allquestions");
//			
//			if((int)httpsession.getAttribute("qno")<=listofquestions.size()-2) //3-2=1 i.e 1 index element
//			{
//				
//			
//			
//			httpsession.setAttribute("qno",(int)httpsession.getAttribute("qno")+1);
//			
//			//List<Questions> listofquestions=(List<Questions>)httpsession.getAttribute("allquestions");
//			Questions question=listofquestions.get((int)httpsession.getAttribute("qno"));
//			
//			
//			
//
//			modelAndView.setViewName("questions");
//			modelAndView.addObject("question",question);
//		}
//			
//			else {
//				modelAndView.setViewName("questions");
//				
//				modelAndView.addObject("question",listofquestions.get(listofquestions.size()-1));//
//				
//				modelAndView.addObject("message","questions are over!");
//			}
//			return modelAndView;
//			
//			
//				
//		}
//		
//		
//
//		@RequestMapping("previous")
//		public ModelAndView nprevious(HttpServletRequest request)
//		{
//			ModelAndView modelAndView=new ModelAndView();
//			
//			
//			
//			HttpSession httpsession=request.getSession();
//		   List<Questions> listofquestions=(List<Questions>)httpsession.getAttribute("allquestions");
//			
//			if((int)httpsession.getAttribute("qno")>0) {
//				
//			
//			
//			httpsession.setAttribute("qno",(int)httpsession.getAttribute("qno")-1);
//			
//			//List<Questions> listofquestions=(List<Questions>)httpsession.getAttribute("allquestions");
//			Questions question=listofquestions.get((int)httpsession.getAttribute("qno"));
//			
//
//			modelAndView.setViewName("questions");
//			modelAndView.addObject("question",question);
//		}
//			
//			else {
//				modelAndView.setViewName("questions");
//				
//				modelAndView.addObject("question",listofquestions.get(listofquestions.size()-3));
//				
//				modelAndView.addObject("message","questions are over!");
//			}
//			return modelAndView;
//			
//			
//				
//		}
//		


}