package com.example.Online_Exam_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineExamProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
