package com.example.pharma.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice //use to handler global exception when any exception occured it will handler by @RestControlleerHandler
public class GlobalExceptionHandler {
    @ExceptionHandler(ResourceNotFoundException.class)   //handlen specific exception and send reponse back to client


    ResponseEntity<ApiResponse>resourceNotFoundHandler(ResourceNotFoundException ex){
        String msg=ex.getMessage();
        ApiResponse response=  ApiResponse
               .builder()                // at a time to store multiple object
              .message(msg)
              .success(false)
               .build();
       // response.builder().message(msg).success(false);    // use to call multiple methods
//        response.setMessage(ex.getMessage());
//        response.setSuccess(false);
        return ResponseEntity.ok(response);
    }

    @ExceptionHandler(CannotUpdateDate.class)
    ResponseEntity<ApiResponse>cannotUpdateDateHandler(CannotUpdateDate ex){
        String msg=ex.getMessage();
        ApiResponse response= ApiResponse
                .builder()
                .message(msg)
                .success(false)
                .build();
        return new ResponseEntity<ApiResponse>(response, HttpStatus.BAD_REQUEST);
    }
}