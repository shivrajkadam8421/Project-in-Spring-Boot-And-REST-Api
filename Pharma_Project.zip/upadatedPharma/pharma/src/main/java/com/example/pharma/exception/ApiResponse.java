package com.example.pharma.exception;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder    // use to call multiple methods
public class ApiResponse {          //contains deatails of exception and send back to client
    private String message;
    private boolean success;

}
