package com.example.pharma;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PharmaApplicationTests {

	@Test
	void contextLoads() {
	}

}
